Non-ASR boundary audit, 12 September 2026; HTML publication 13 September 2026.
Numerical evidence is unchanged. Absolute cluster paths in JSON have portable $PROJECT/$WORKSPACE prefixes.
source_sha256.json hashes original local evidence before path substitution.
Classification quality is from saved TEST records. Boundary inference is a separate evaluation.
Selected-checkpoint quality must not be paired with last-step boundary rates.
No datasets, audio, checkpoints, or manuscript files are included.
